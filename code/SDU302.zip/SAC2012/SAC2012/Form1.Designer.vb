﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lststock = New System.Windows.Forms.ListBox()
        Me.lstrestock = New System.Windows.Forms.ListBox()
        Me.lbldataSOH = New System.Windows.Forms.Label()
        Me.lblSOH = New System.Windows.Forms.Label()
        Me.lblminstock = New System.Windows.Forms.Label()
        Me.lblsold = New System.Windows.Forms.Label()
        Me.lblcolor = New System.Windows.Forms.Label()
        Me.lbldataminstock = New System.Windows.Forms.Label()
        Me.lbldatasold = New System.Windows.Forms.Label()
        Me.lbldatacolor = New System.Windows.Forms.Label()
        Me.btnstatus = New System.Windows.Forms.Button()
        Me.btnrestock = New System.Windows.Forms.Button()
        Me.lblstock = New System.Windows.Forms.Label()
        Me.lblrestock = New System.Windows.Forms.Label()
        Me.lstshopping = New System.Windows.Forms.ListBox()
        Me.lblshopping = New System.Windows.Forms.Label()
        Me.btnhelp = New System.Windows.Forms.Button()
        Me.lbldetails = New System.Windows.Forms.Label()
        Me.lblcontrols = New System.Windows.Forms.Label()
        Me.lblsupplier = New System.Windows.Forms.Label()
        Me.lbldatasupplier = New System.Windows.Forms.Label()
        Me.lblprice = New System.Windows.Forms.Label()
        Me.lbldataprice = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lststock
        '
        Me.lststock.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lststock.FormattingEnabled = True
        Me.lststock.ItemHeight = 24
        Me.lststock.Location = New System.Drawing.Point(12, 32)
        Me.lststock.Name = "lststock"
        Me.lststock.Size = New System.Drawing.Size(279, 652)
        Me.lststock.TabIndex = 0
        '
        'lstrestock
        '
        Me.lstrestock.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstrestock.FormattingEnabled = True
        Me.lstrestock.ItemHeight = 24
        Me.lstrestock.Location = New System.Drawing.Point(297, 296)
        Me.lstrestock.Name = "lstrestock"
        Me.lstrestock.Size = New System.Drawing.Size(279, 388)
        Me.lstrestock.TabIndex = 1
        '
        'lbldataSOH
        '
        Me.lbldataSOH.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbldataSOH.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldataSOH.Location = New System.Drawing.Point(390, 32)
        Me.lbldataSOH.Name = "lbldataSOH"
        Me.lbldataSOH.Size = New System.Drawing.Size(359, 20)
        Me.lbldataSOH.TabIndex = 2
        Me.lbldataSOH.Text = "placeholder"
        Me.lbldataSOH.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSOH
        '
        Me.lblSOH.AutoSize = True
        Me.lblSOH.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSOH.Location = New System.Drawing.Point(302, 32)
        Me.lblSOH.Name = "lblSOH"
        Me.lblSOH.Size = New System.Drawing.Size(119, 20)
        Me.lblSOH.TabIndex = 3
        Me.lblSOH.Text = "Stock on Hand:"
        '
        'lblminstock
        '
        Me.lblminstock.AutoSize = True
        Me.lblminstock.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblminstock.Location = New System.Drawing.Point(302, 54)
        Me.lblminstock.Name = "lblminstock"
        Me.lblminstock.Size = New System.Drawing.Size(153, 20)
        Me.lblminstock.TabIndex = 3
        Me.lblminstock.Text = "Minimum stock level:"
        '
        'lblsold
        '
        Me.lblsold.AutoSize = True
        Me.lblsold.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsold.Location = New System.Drawing.Point(302, 76)
        Me.lblsold.Name = "lblsold"
        Me.lblsold.Size = New System.Drawing.Size(115, 20)
        Me.lblsold.TabIndex = 3
        Me.lblsold.Text = "Sold this week:"
        '
        'lblcolor
        '
        Me.lblcolor.AutoSize = True
        Me.lblcolor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcolor.Location = New System.Drawing.Point(302, 143)
        Me.lblcolor.Name = "lblcolor"
        Me.lblcolor.Size = New System.Drawing.Size(60, 20)
        Me.lblcolor.TabIndex = 3
        Me.lblcolor.Text = "Status:"
        '
        'lbldataminstock
        '
        Me.lbldataminstock.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbldataminstock.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldataminstock.Location = New System.Drawing.Point(413, 54)
        Me.lbldataminstock.Name = "lbldataminstock"
        Me.lbldataminstock.Size = New System.Drawing.Size(336, 20)
        Me.lbldataminstock.TabIndex = 2
        Me.lbldataminstock.Text = "placeholder"
        Me.lbldataminstock.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbldatasold
        '
        Me.lbldatasold.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbldatasold.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldatasold.Location = New System.Drawing.Point(387, 76)
        Me.lbldatasold.Name = "lbldatasold"
        Me.lbldatasold.Size = New System.Drawing.Size(362, 20)
        Me.lbldatasold.TabIndex = 2
        Me.lbldatasold.Text = "placeholder"
        Me.lbldatasold.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lbldatacolor
        '
        Me.lbldatacolor.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbldatacolor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldatacolor.Location = New System.Drawing.Point(345, 143)
        Me.lbldatacolor.Name = "lbldatacolor"
        Me.lbldatacolor.Size = New System.Drawing.Size(404, 20)
        Me.lbldatacolor.TabIndex = 2
        Me.lbldatacolor.Text = "placeholder"
        Me.lbldatacolor.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'btnstatus
        '
        Me.btnstatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstatus.Location = New System.Drawing.Point(582, 427)
        Me.btnstatus.Name = "btnstatus"
        Me.btnstatus.Size = New System.Drawing.Size(186, 120)
        Me.btnstatus.TabIndex = 4
        Me.btnstatus.Text = "Update Status"
        Me.btnstatus.UseVisualStyleBackColor = True
        '
        'btnrestock
        '
        Me.btnrestock.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrestock.Location = New System.Drawing.Point(582, 296)
        Me.btnrestock.Name = "btnrestock"
        Me.btnrestock.Size = New System.Drawing.Size(186, 120)
        Me.btnrestock.TabIndex = 6
        Me.btnrestock.Text = "Generate shopping list"
        Me.btnrestock.UseVisualStyleBackColor = True
        '
        'lblstock
        '
        Me.lblstock.AutoSize = True
        Me.lblstock.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstock.Location = New System.Drawing.Point(12, 1)
        Me.lblstock.Name = "lblstock"
        Me.lblstock.Size = New System.Drawing.Size(208, 25)
        Me.lblstock.TabIndex = 8
        Me.lblstock.Text = "Current Stock List:"
        '
        'lblrestock
        '
        Me.lblrestock.AutoSize = True
        Me.lblrestock.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblrestock.Location = New System.Drawing.Point(297, 263)
        Me.lblrestock.Name = "lblrestock"
        Me.lblrestock.Size = New System.Drawing.Size(215, 25)
        Me.lblrestock.TabIndex = 9
        Me.lblrestock.Text = "New Shopping List:"
        '
        'lstshopping
        '
        Me.lstshopping.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstshopping.FormattingEnabled = True
        Me.lstshopping.ItemHeight = 24
        Me.lstshopping.Location = New System.Drawing.Point(774, 32)
        Me.lstshopping.Name = "lstshopping"
        Me.lstshopping.Size = New System.Drawing.Size(230, 652)
        Me.lstshopping.TabIndex = 7
        '
        'lblshopping
        '
        Me.lblshopping.AutoSize = True
        Me.lblshopping.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshopping.Location = New System.Drawing.Point(774, 1)
        Me.lblshopping.Name = "lblshopping"
        Me.lblshopping.Size = New System.Drawing.Size(163, 25)
        Me.lblshopping.TabIndex = 10
        Me.lblshopping.Text = "Shopping List:"
        '
        'btnhelp
        '
        Me.btnhelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhelp.Location = New System.Drawing.Point(582, 563)
        Me.btnhelp.Name = "btnhelp"
        Me.btnhelp.Size = New System.Drawing.Size(186, 121)
        Me.btnhelp.TabIndex = 11
        Me.btnhelp.Text = "Help"
        Me.btnhelp.UseVisualStyleBackColor = True
        '
        'lbldetails
        '
        Me.lbldetails.AutoSize = True
        Me.lbldetails.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldetails.Location = New System.Drawing.Point(305, 1)
        Me.lbldetails.Name = "lbldetails"
        Me.lbldetails.Size = New System.Drawing.Size(140, 25)
        Me.lbldetails.TabIndex = 12
        Me.lbldetails.Text = "Item details:"
        '
        'lblcontrols
        '
        Me.lblcontrols.AutoSize = True
        Me.lblcontrols.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcontrols.Location = New System.Drawing.Point(582, 263)
        Me.lblcontrols.Name = "lblcontrols"
        Me.lblcontrols.Size = New System.Drawing.Size(107, 25)
        Me.lblcontrols.TabIndex = 13
        Me.lblcontrols.Text = "Controls:"
        '
        'lblsupplier
        '
        Me.lblsupplier.AutoSize = True
        Me.lblsupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsupplier.Location = New System.Drawing.Point(302, 122)
        Me.lblsupplier.Name = "lblsupplier"
        Me.lblsupplier.Size = New System.Drawing.Size(71, 20)
        Me.lblsupplier.TabIndex = 15
        Me.lblsupplier.Text = "Supplier:"
        '
        'lbldatasupplier
        '
        Me.lbldatasupplier.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbldatasupplier.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldatasupplier.Location = New System.Drawing.Point(356, 122)
        Me.lbldatasupplier.Name = "lbldatasupplier"
        Me.lbldatasupplier.Size = New System.Drawing.Size(393, 20)
        Me.lbldatasupplier.TabIndex = 14
        Me.lbldatasupplier.Text = "placeholder"
        Me.lbldatasupplier.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblprice
        '
        Me.lblprice.AutoSize = True
        Me.lblprice.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblprice.Location = New System.Drawing.Point(302, 100)
        Me.lblprice.Name = "lblprice"
        Me.lblprice.Size = New System.Drawing.Size(48, 20)
        Me.lblprice.TabIndex = 17
        Me.lblprice.Text = "Price:"
        '
        'lbldataprice
        '
        Me.lbldataprice.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbldataprice.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldataprice.Location = New System.Drawing.Point(342, 100)
        Me.lbldataprice.Name = "lbldataprice"
        Me.lbldataprice.Size = New System.Drawing.Size(407, 20)
        Me.lbldataprice.TabIndex = 16
        Me.lbldataprice.Text = "placeholder"
        Me.lbldataprice.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1016, 701)
        Me.Controls.Add(Me.lblprice)
        Me.Controls.Add(Me.lbldataprice)
        Me.Controls.Add(Me.lblsupplier)
        Me.Controls.Add(Me.lbldatasupplier)
        Me.Controls.Add(Me.lblcontrols)
        Me.Controls.Add(Me.lbldetails)
        Me.Controls.Add(Me.btnhelp)
        Me.Controls.Add(Me.lblshopping)
        Me.Controls.Add(Me.lblrestock)
        Me.Controls.Add(Me.lblstock)
        Me.Controls.Add(Me.lstshopping)
        Me.Controls.Add(Me.btnrestock)
        Me.Controls.Add(Me.btnstatus)
        Me.Controls.Add(Me.lblcolor)
        Me.Controls.Add(Me.lblsold)
        Me.Controls.Add(Me.lblminstock)
        Me.Controls.Add(Me.lblSOH)
        Me.Controls.Add(Me.lbldatacolor)
        Me.Controls.Add(Me.lbldatasold)
        Me.Controls.Add(Me.lbldataminstock)
        Me.Controls.Add(Me.lbldataSOH)
        Me.Controls.Add(Me.lstrestock)
        Me.Controls.Add(Me.lststock)
        Me.Name = "Form1"
        Me.Text = "Stock Manager - Janson's Supermarkets"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lststock As System.Windows.Forms.ListBox
    Friend WithEvents lstrestock As System.Windows.Forms.ListBox
    Friend WithEvents lbldataSOH As System.Windows.Forms.Label
    Friend WithEvents lblSOH As System.Windows.Forms.Label
    Friend WithEvents lblminstock As System.Windows.Forms.Label
    Friend WithEvents lblsold As System.Windows.Forms.Label
    Friend WithEvents lblcolor As System.Windows.Forms.Label
    Friend WithEvents lbldataminstock As System.Windows.Forms.Label
    Friend WithEvents lbldatasold As System.Windows.Forms.Label
    Friend WithEvents lbldatacolor As System.Windows.Forms.Label
    Friend WithEvents btnstatus As System.Windows.Forms.Button
    Friend WithEvents btnrestock As System.Windows.Forms.Button
    Friend WithEvents lblstock As System.Windows.Forms.Label
    Friend WithEvents lblrestock As System.Windows.Forms.Label
    Friend WithEvents lstshopping As System.Windows.Forms.ListBox
    Friend WithEvents lblshopping As System.Windows.Forms.Label
    Friend WithEvents btnhelp As System.Windows.Forms.Button
    Friend WithEvents lbldetails As System.Windows.Forms.Label
    Friend WithEvents lblcontrols As System.Windows.Forms.Label
    Friend WithEvents lblsupplier As System.Windows.Forms.Label
    Friend WithEvents lbldatasupplier As System.Windows.Forms.Label
    Friend WithEvents lblprice As System.Windows.Forms.Label
    Friend WithEvents lbldataprice As System.Windows.Forms.Label

End Class
