﻿Imports System.IO
Public Class Form1
    Dim stock(1, 6) As String
    Dim product() As String
    Dim stocklistlength As Integer = 1
    Dim productid As Integer = 0
    'variables for array dimensions.
    Dim itemname As Integer = 0
    Dim SOH As Integer = 1
    Dim Minstock As Integer = 2
    Dim stocksold As Integer = 3
    Dim price As Integer = 4
    Dim supplier As Integer = 5
    Dim status As Integer = 6

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load 'Reads data in from files and adds to listbox and array
        lbldataSOH.Text = " "
        lbldataminstock.Text = " "
        lbldatasold.Text = " "
        lbldataprice.Text = " "
        lbldatasupplier.Text = " "
        lbldatacolor.Text = " "

        Dim Stock_File As StreamReader = File.OpenText("stocklist.csv") 'gets amount of lines of text file and adjusts array accoringly
        Do While Stock_File.Peek <> -1
            Stock_File.ReadLine()
            stocklistlength = stocklistlength + 1
        Loop
        stocklistlength = stocklistlength - 2
        Stock_File.Close()
        ReDim stock(stocklistlength, 6)

        Dim Stock_File2 As StreamReader = File.OpenText("stocklist.csv") 'reads and stores stocklist
        Do While Stock_File2.Peek <> -1
            product = Split(Stock_File2.ReadLine(), ",")
            For x = LBound(stock, 2) To UBound(stock, 2)
                stock(productid, x) = product(x)
            Next
            lststock.Items.Add(stock(productid, itemname))
            productid = productid + 1
        Loop
        Stock_File2.Close()

        Dim CurrentShoppinglist As StreamReader = File.OpenText("shoppinglist.txt") 'reads and stores past shopping list
        Do While CurrentShoppinglist.Peek <> -1
            lstshopping.Items.Add(CurrentShoppinglist.ReadLine())
        Loop
        CurrentShoppinglist.Close()
    End Sub

    Private Sub lststock_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lststock.SelectedIndexChanged 'display data of selected product in labels
        lbldataSOH.Text = stock(lststock.SelectedIndex, SOH)
        lbldataminstock.Text = stock(lststock.SelectedIndex, Minstock)
        lbldatasold.Text = stock(lststock.SelectedIndex, stocksold)
        lbldataprice.Text = "$" + stock(lststock.SelectedIndex, price)
        lbldatasupplier.Text = stock(lststock.SelectedIndex, supplier)
        lbldatacolor.Text = stock(lststock.SelectedIndex, status)
        lbldatacolor.ForeColor = Color.FromName(stock(lststock.SelectedIndex, status))

    End Sub
    Private Sub colour() 'function for generating status 
        productid = 0
        Do While productid < stocklistlength + 1
            If Val(stock(productid, stocksold)) / Val(stock(productid, Minstock)) <= 0.1 Then
                If stock(productid, status) = "green" Then
                    stock(productid, status) = "yellow"
                ElseIf stock(productid, status) = "yellow" Then
                    stock(productid, status) = "red"
                End If
            End If
            productid += 1
        Loop
    End Sub
    Private Sub stocklevels() 'determines what products need to be ordered
        productid = 0
        Do While productid < stocklistlength + 1
            If Val(stock(productid, SOH)) < Val(stock(productid, Minstock)) Then
                Dim quantity As String
                quantity = -(Val(stock(productid, SOH)) - Val(stock(productid, Minstock)))
                lstrestock.Items.Add(stock(productid, 0) + ": " + quantity)
            End If
            productid += 1
        Loop
    End Sub
    Private Sub save() 'saves both the shopping list and the stocklist
        Dim Shoppinglist As StreamWriter = File.CreateText("shoppinglist.txt")
        Dim Stock_File3 As StreamWriter = File.CreateText("stocklist.csv")
        For x = LBound(stock, 1) To UBound(stock, 1)
            Stock_File3.WriteLine(stock(x, itemname) + "," + stock(x, SOH) + "," + stock(x, Minstock) + "," + stock(x, stocksold) + "," + stock(x, price) + "," + stock(x, supplier) + "," + stock(x, status))
        Next
        Stock_File3.Close()

        For Each Product As String In lstrestock.Items
            Shoppinglist.WriteLine(Product)
        Next
        Shoppinglist.Close()
    End Sub

    Private Sub btnstatus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnstatus.Click ' updates colour status and updates details if selected
        colour()

        If lststock.SelectedIndex > -1 Then
            lbldatacolor.ForeColor = Color.FromName(stock(lststock.SelectedIndex, status))
            lbldatacolor.Text = stock(lststock.SelectedIndex, status)
        End If
        btnstatus.Enabled = False
    End Sub
    Private Sub btnrestock_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrestock.Click 'determines what products need to be ordered and disables certain buttons.
        stocklevels()
        btnrestock.Enabled = False
    End Sub

    Private Sub btnhelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnhelp.Click 'displays basic help dialog
        MsgBox("The Current stock list holds the list of current stock. If an item is selected, its details will appear to the right of the list, in the Item details section.")
        MsgBox("Below the Item details section is the Controls section. This allows use of a number of functions.")
        MsgBox("Generate shopping list will place a list of items that need to be purchased in the New shopping list. The Update Status button will update the status of each item to either green, yellow (slightly discounted) or red (heavily discounted).")
        MsgBox("On the far right of the program, there is the Shopping list. It displays the last generated New shopping list.")
        MsgBox("The program will save the stocklist and shopping list on exit.")
        MsgBox("This program comes with lifetime tech support. Please contact jonathan@mhscoders.com for any assisstance. (c) 2012 MhsCoders")
    End Sub
    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing 'saves and exits. Makes sure the user has not forgotten to generate a shopping list
        If btnrestock.Enabled = True Then
            Dim UserSelection As Integer = MsgBox("Do you want to exit without generating a shopping list?", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo, "Exit Application")
            If UserSelection <> 6 Then 'if user selects yes.
                e.Cancel = True
            Else
                save()
                Me.Dispose()
            End If
        Else
            save()
            Me.Dispose()
        End If
    End Sub
End Class
