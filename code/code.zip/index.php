<?php
$title = "<your page title here>";
require_once("head.php")
?>

Content
Content 

<?php
require_once("foot.php")
?>
