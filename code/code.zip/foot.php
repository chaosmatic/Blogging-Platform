<?php
echo "</div>";
echo "<div id=contenta>";
echo "adcode</div>"; //this div is for advertisements
echo "</div>";
echo " </body>";
?>
