<?php
echo "<!DOCTYPE html><head><meta http-equiv='content-type' content='text/html;charset=UTF-8'><link rel='shortcut icon' href='favicon.ico'><LINK REL=StyleSheet HREF='".$dir."style.css' TYPE='text/css' MEDIA=screen>";
echo "<title>".$title."</title>"; //title in top of browser
echo "</head>";

echo "<body link='#F01010' vlink='#B01010'>";

echo "<div id=wrapper>";
echo "<div id=head><center>";
echo "<font size='70'> <font color='#F01010'>Milfords</font>World<font color='#808080'>.com</font></font>"; //title at top of page

echo "</center>";
	echo "</div>";

	echo "<ul id='list-nav'>";
	echo "<li><a href='".$dir."index.php'>Home</a> </li>"; //these are the links at the top of page. between the > < is the appearance, in the ' ' is the location
	echo "<li><a href='".$dir."code/index.php'>Code</a> </li>";
	echo "<li><a href='".$dir."minecraft/index.php'>Minecraft</a> </li>";
	echo "<li><a href='".$dir."articles/index.php'>Articles</a></li>";
echo "</ul><br>";
   echo "<div id=content>";
?>
